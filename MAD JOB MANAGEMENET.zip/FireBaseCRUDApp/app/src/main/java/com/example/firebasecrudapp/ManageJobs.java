package com.example.firebasecrudapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ManageJobs extends AppCompatActivity {

    EditText mjetTitle,mjetName,mjetDescription,mjetContactNumber;
    Button btn_view,btn_update,btn_delete;
    Worker workerObj;
    DatabaseReference dbRef;
    String TITILE,NAME,DESCRIPTION,NUMBER;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_jobs);

        mjetTitle=findViewById(R.id.mjet_title);
        mjetName=findViewById(R.id.mjet_name);
        mjetDescription=findViewById(R.id.mjet_description);
        mjetContactNumber=findViewById(R.id.mjet_contact);
        btn_update=findViewById(R.id.btn_update);
        btn_delete=findViewById(R.id.btn_delete);

        showjobData();
        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference upRef = FirebaseDatabase.getInstance().getReference().child("Worker");
                upRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild("a1")){
                            TITILE= mjetTitle.getEditableText().toString();
                            NAME =mjetName.getEditableText().toString();
                            DESCRIPTION = mjetDescription.getEditableText().toString();
                            NUMBER=mjetContactNumber.getEditableText().toString();

                            dbRef.child("a1").child("title").setValue(mjetTitle.getEditableText().toString());
                            dbRef.child("a1").child("name").setValue(mjetName.getEditableText().toString());
                            dbRef.child("a1").child("description").setValue(mjetDescription.getEditableText().toString());
                            dbRef.child("a1").child("contactNumber").setValue(mjetContactNumber.getEditableText().toString());

                            Toast.makeText(getApplicationContext(), "Data Updated", Toast.LENGTH_SHORT).show();
                        }
                        else
                            Toast.makeText(getApplicationContext(), "Nothing to Display", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }

        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference deRef =FirebaseDatabase.getInstance().getReference().child("Worker");
                deRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.hasChild("Prasad")) {

                            dbRef = FirebaseDatabase.getInstance().getReference().child("Worker").child("Prasad");
                            dbRef.removeValue();
                            Toast.makeText(getApplicationContext(), "Succesefully Deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Nothing to Delete", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled (@NonNull DatabaseError databaseError){
                    }


                });
            }
        });
    }
    private void showjobData(){
        Intent intent = getIntent();
        String jobtitle = intent.getStringExtra("title");
        String jobname = intent.getStringExtra("name");
        String jobdescription = intent.getStringExtra("description");
        String jobcontactNumber = intent.getStringExtra("contactNumber");

        mjetTitle.setText(jobtitle);
        mjetName.setText(jobname);
        mjetDescription.setText(jobdescription);
        mjetContactNumber.setText(jobcontactNumber);

    }
}