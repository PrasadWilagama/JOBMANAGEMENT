package com.example.firebasecrudapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText etTitle,etName,etDescription,etContactNumber;
    Button btn_save,btn_view;
    Worker workerObj;
    DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTitle=findViewById(R.id.et_title);
        etName=findViewById(R.id.et_name);
        etDescription=findViewById(R.id.et_description);
        etContactNumber=findViewById(R.id.et_contact);
        btn_save=findViewById(R.id.btn_save);
        btn_view=findViewById(R.id.btn_view);


        workerObj = new Worker();
    }
    public void ClearControls(){
        etTitle.setText("");
        etName.setText("");
        etDescription.setText("");
        etContactNumber.setText("");

    }
    public void CreateData(View view){
        dbRef= FirebaseDatabase.getInstance().getReference().child("Worker");
        try {
            if (TextUtils.isEmpty(etTitle.getText().toString())) {
                Toast.makeText(getApplicationContext(), "Please Enter a Title", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(etName.getText().toString())) {
                Toast.makeText(getApplicationContext(), "Enter a name", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(etDescription.getText().toString())) {
                Toast.makeText(getApplicationContext(), "Enter a Description", Toast.LENGTH_SHORT).show();
            } else if (TextUtils.isEmpty(etContactNumber.getText().toString())) {
                Toast.makeText(getApplicationContext(), "Enter a Contact Number", Toast.LENGTH_SHORT).show();
            } else {
                workerObj.setTitle(etTitle.getText().toString().trim());
                workerObj.setName(etName.getText().toString().trim());
                workerObj.setDescription(etDescription.getText().toString().trim());
                workerObj.setContactNumber(etContactNumber.getText().toString().trim());

                // dbRef.push().setValue(workerObj);
                 dbRef.child(workerObj.getName()).setValue(workerObj);

                Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();
                ClearControls();
            }
        }catch (NumberFormatException e){
        Toast.makeText(getApplicationContext(),"Invalid Format",Toast.LENGTH_SHORT).show();
        }
    }

    public void ShowData(View view) {
        DatabaseReference readRef = FirebaseDatabase.getInstance().getReference().child("Worker").child("Prasad");
        readRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChildren()) {

                    String titledb = snapshot.child("title").getValue(String.class);
                    String Namedb =  snapshot.child("name").getValue(String.class);
                    String Descriptiondb = snapshot.child("description").getValue(String.class);
                    String ContactNumberdb=snapshot.child("contactNumber").getValue(String.class);
                    Intent intent = new Intent(getApplicationContext(), ManageJobs.class);

                    intent.putExtra("title", titledb);
                    intent.putExtra("name", Namedb);
                    intent.putExtra("description", Descriptiondb);
                    intent.putExtra("contactNumber", ContactNumberdb);

                    startActivity(intent);
                } else

                    Toast.makeText(getApplicationContext(), "No Source to Display", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}

